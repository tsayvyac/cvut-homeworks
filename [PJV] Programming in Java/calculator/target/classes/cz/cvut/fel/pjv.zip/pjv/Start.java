/*
 * File name: Start.java
 * Date:      2014/09/04 12:34
 * Author:    @author
 */

package cz.cvut.fel.pjv;

public class Start {

   public static void main(String[] args) {
      Lab01 lab = new Lab01();
      lab.homework(args);
   }

}
